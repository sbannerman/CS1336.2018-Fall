#!/bin/bash

if [ $# -ne 1 ]; then
  echo "Usage: $0 <scenario dir>"
  exit 1
fi

SCENARIO_DIR=$1

EXECUTABLE="./assignment27.exe"

cd `dirname $0`
echo "Executing ${SCENARIO_DIR}..."
${EXECUTABLE} ./${SCENARIO_DIR}/input.txt ./${SCENARIO_DIR}/output-actual.txt > ./${SCENARIO_DIR}/console-actual.txt
EXIT_CODE=$?
echo "Executed ${SCENARIO_DIR} (exitCode=${EXIT_CODE})..."
