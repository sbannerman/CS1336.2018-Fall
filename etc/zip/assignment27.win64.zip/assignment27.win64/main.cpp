#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>

using namespace std;

// Constants

const string ID_LINE = "Steve Bannerman - CS 1336 - Assignment 27";

const string OUTPUT_PREFIX_INPUT_COLUMNS = "Number of columns in input file: ";
const string OUTPUT_PREFIX_INPUT_ROWS = "Number of rows in input file: ";

const string OUTPUT_PREFIX_OUTPUT_COLUMNS = "Number of columns in output file: ";
const string OUTPUT_PREFIX_OUTPUT_ROWS = "Number of rows in output file: ";

ifstream openInputFileStream(string inputFilePath)
{
    ifstream inputFileStream;
    inputFileStream.open(inputFilePath);
    return inputFileStream;
}

ofstream openOutputFileStream(string outputFilePath)
{
    ofstream outputFileStream(outputFilePath);
    return outputFileStream;
}

int main(int argc, char *argv[])
{
    // guard clause - invalid number of arguments
    if (argc != 3)
    {
        cout << "Usage: " << argv[0] << " <input file path> <output file path>" << endl;
        return 1;
    }

    string inputFilePath = argv[1];
    string outputFilePath = argv[2];

    // guard clause - input file problem
    ifstream inputFileStream = openInputFileStream(inputFilePath);
    if (!inputFileStream.good())
    {
        cout << "Unable to open input file stream: " << inputFilePath << endl;
        return 1;
    }

    // guard clause - output file problem
    ofstream outputFileStream = openOutputFileStream(outputFilePath);
    if (!outputFileStream.good())
    {
        cout << "Unable to open output file stream: " << outputFilePath << endl;
        inputFileStream.close();
        return 1;
    }

    // read the first line to get the number of rows and columns
    string firstInputLine;
    getline(inputFileStream, firstInputLine);
    stringstream firstInputStream(firstInputLine);
    int numRows = 0;
    int numColumns = 0;
    firstInputStream >> numRows >> numColumns;

    // read the subsequent lines and load a grid with their values
    int grid[numRows][numColumns];
    for (int row = 0; row < numRows; row++)
    {
        string nextInputLine;
        getline(inputFileStream, nextInputLine);
        stringstream nextInputStream(nextInputLine);

        for (int column = 0; column < numColumns; column++)
        {
            nextInputStream >> grid[row][column];
        }
    }

    // write an inverted grid to the output file
    outputFileStream << numColumns << " " << numRows << endl;
    for (int column = 0; column < numColumns; column++)
    {
        for (int row = 0; row < numRows; row++)
        {
            outputFileStream << grid[row][column];
            if (row > 0)
            {
                outputFileStream << " ";
            }
        }
        outputFileStream << endl;
    }

    // close the input and output streams, as done with them now
    outputFileStream.close();
    inputFileStream.close();

    // output the summary to the console
    cout << ID_LINE << endl;
    cout << endl;

    cout << OUTPUT_PREFIX_INPUT_ROWS << numRows << endl;
    cout << OUTPUT_PREFIX_INPUT_COLUMNS << numColumns << endl;
    cout << endl;

    cout << OUTPUT_PREFIX_OUTPUT_ROWS << numColumns << endl;
    cout << OUTPUT_PREFIX_OUTPUT_COLUMNS << numRows << endl;

    return 0;
}