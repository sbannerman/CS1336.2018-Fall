#!/bin/bash

if [ $# -ne 1 ]; then
  echo "Usage: $0 <scenario dir>"
  exit 1
fi

SCENARIO_DIR=$1

cd `dirname $0`
echo "deleting actual output and console files for ${SCENARIO_DIR}..."

rm ./${SCENARIO_DIR}/output-actual.txt
rm ./${SCENARIO_DIR}/console-actual.txt

echo "deleted actual output and console files for ${SCENARIO_DIR}."
