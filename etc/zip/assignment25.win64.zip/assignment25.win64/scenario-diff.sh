#!/bin/bash

if [ $# -ne 1 ]; then
  echo "Usage: $0 <scenario dir>"
  exit 1
fi

SCENARIO_DIR=$1

EXECUTABLE="diff"

cd `dirname $0`
echo "--"
echo "diff'ing expected and actual output files for ${SCENARIO_DIR}..."
echo "--"
${EXECUTABLE} ./${SCENARIO_DIR}/output-expected.txt ./${SCENARIO_DIR}/output-actual.txt
echo "--"

echo "--"
echo "diff'ing expected and actual output console for ${SCENARIO_DIR}..."
echo "--"
${EXECUTABLE} ./${SCENARIO_DIR}/console-expected.txt ./${SCENARIO_DIR}/console-actual.txt

echo "--"
