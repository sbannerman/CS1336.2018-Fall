This set of files contains several test scenarios and some scripts to execute them.
Each test scenario contains an input file and expected output files.
And, the scripts can be used to "wire together" my our your program with those.

This set of files is intended to be useful on a Windows 64 bit machine.
If you're using a different Windows operating system and/or 32 bit machine, it may work.
If you're using a different operating system (Linux, MacOS), it won't work.

I put together the batch scripts for you to use, rather than you needing to worry
too much about how to execute your program and/or redirect its console output to a file.
But, if you're on a different operating system, you'll need to put together some
alternative scripts (I may be able to help you with that)...however, the input files
and expected output files can still be useful.

When you first download and extract the zip archive, there is an assignment25.exe file.
That is a program that I developed for this assignment.
Once you've got a version of your program developed, you'll want to rename mine and
then name/rename your program to assignment25.exe in this same directory (to make sure 
that the scripts use your program instead of my program).

Here is how to use these scripts after opening up a command prompt in this directory...note
that I extracted the .zip archive into the D:\Test directory (rather than the
D:\Test\assignment25 directory that Windows will suggest to you by default):

--
Usage: scenario-test.bat <scenario dir>
--
D:\Test\assignment25.win64>scenario-test.bat scenario-0
Executing scenario-0...
Executed scenario-0 (exitCode=0).
--
This batch script will execute the assignment25.exe program with its two arguments
(input file path and output file path) and redirect its console output for you.
If you're interested in how it does this, you can open the .bat file with a text editor.

Once it has executed, the actual output and console files will be created in the scenario
directory and then you'll be ready for using the 'diff' script.

Alternatively, you can open the actual and expected files in your text editor.

--
Usage: scenario-diff.bat <scenario dir>
--
D:\Test\assignment25.win64>scenario-diff.bat scenario-0
--
diff'ing expected and actual output files for scenario-0...
--
--
diff'ing expected and actual console files for scenario-0...
--
--
--
This batch script will execute the diff program and compare the two pairs of output files.
It will compare the expected and actual output files.
And, it will compare the expected and actual console files.

Any differences (other than your name) are likely indicators that your program is not
working as specified.

--
Usage: scenario-clean.bat <scenario dir>
--
D:\Test\assignment25.win64>scenario-clean.bat scenario-0
deleting actual output and console files for scenario-0...
deleted actual output and console files for scenario-0 (exitCode=0).
--
This script cleans up the actual output and actual console files, if you want to.

Of course, you can clean those up by hand as well, but be careful not to get rid of
the input file or the expected output files...they will still be available in the
zip file from github.com, but it might be a pain to go back and get them or re-extract
them several times.

Strictly speaking, you shouldn't need to clean up the actual files...if you use the
scenario-test.bat script again, it should/will overwrite them anyhow.
