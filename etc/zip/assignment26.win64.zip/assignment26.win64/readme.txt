This set of files is very similar to the set for assignment 25...please refer to that readme.txt file.

The only significant difference is that when you copy your own compiled program into this
directory, you should rename it to assignment26.exe (rather than assignment25.exe).
Everything else should be the same.
